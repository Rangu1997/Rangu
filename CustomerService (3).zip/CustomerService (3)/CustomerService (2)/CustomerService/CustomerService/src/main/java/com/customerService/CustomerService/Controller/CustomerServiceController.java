package com.customerService.CustomerService.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.customerService.CustomerService.Entity.CustomerSevice;
import com.customerService.CustomerService.Service.CustomerServiceService;

@RestController
@RequestMapping("customer")
public class CustomerServiceController {
	@Autowired
	private CustomerServiceService customerServiceService;
	
	@PostMapping("/save-Details")
	public String saveDetails(@RequestBody CustomerSevice customerSevice) {
		
		return customerServiceService.saveDetails(customerSevice);
		
	}
	
	@GetMapping("/get-All-Details")
	public List<CustomerSevice> getAllDetails(){
		
		
		return customerServiceService.getAllDetails();
	}

}
