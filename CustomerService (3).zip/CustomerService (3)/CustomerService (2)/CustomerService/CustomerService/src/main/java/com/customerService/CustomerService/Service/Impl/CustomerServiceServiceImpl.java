package com.customerService.CustomerService.Service.Impl;

import java.util.List;

import javax.activity.InvalidActivityException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.customerService.CustomerService.Entity.CustomerSevice;
import com.customerService.CustomerService.Exception.CustomExcep;
import com.customerService.CustomerService.Repository.CustomerServiceRepo;
import com.customerService.CustomerService.Service.CustomerServiceService;

@Service
public class CustomerServiceServiceImpl implements CustomerServiceService {

	@Autowired
	private CustomerServiceRepo customerServiceRepo;
	@Override
	public String saveDetails(CustomerSevice customerSevice) {
		if(customerSevice.getName()=="") {
            throw new CustomExcep("Invalid Input",CustomerServiceServiceImpl.class);
        }
		customerServiceRepo.save(customerSevice);
		return "Succes";
	}

	@Override
	public List<CustomerSevice> getAllDetails() {
		
		return customerServiceRepo.findAll();
	}

}
