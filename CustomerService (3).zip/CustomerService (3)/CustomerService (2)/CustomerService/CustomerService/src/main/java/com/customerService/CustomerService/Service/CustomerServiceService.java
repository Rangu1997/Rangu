package com.customerService.CustomerService.Service;

import java.util.List;

import com.customerService.CustomerService.Entity.CustomerSevice;

public interface CustomerServiceService {

	public String saveDetails(CustomerSevice customerSevice);

	public List<CustomerSevice> getAllDetails();

}
