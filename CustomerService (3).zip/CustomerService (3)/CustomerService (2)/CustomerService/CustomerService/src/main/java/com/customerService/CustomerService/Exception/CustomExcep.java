package com.customerService.CustomerService.Exception;

public class CustomExcep extends RuntimeException{
	private String message;
	private Class<?> excepClass;
	public CustomExcep() {
		super();
	}
	public CustomExcep(String message,Class<?> excepClass) {
		super(message);
		this.excepClass=excepClass;
		this.message=message;
	}
}


