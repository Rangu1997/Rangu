package com.customerService.CustomerService.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.customerService.CustomerService.Entity.CustomerSevice;

public interface CustomerServiceRepo extends JpaRepository<CustomerSevice, Long> {

	

}
